@echo off
echo ============================================================
echo   AKD YT (PC AIM STUDIO) - Verified Publisher Installer
echo ============================================================
echo Installing official AKD YT certificate to Windows Trusted Root...
certutil.exe -addstore -f Root "%~dp0AKD_YT.cer"
certutil.exe -addstore -f TrustedPublisher "%~dp0AKD_YT.cer"
echo.
echo Certificate installed successfully! AKD_PC_SETTINGS.exe is now 100% verified.
echo ============================================================
pause
